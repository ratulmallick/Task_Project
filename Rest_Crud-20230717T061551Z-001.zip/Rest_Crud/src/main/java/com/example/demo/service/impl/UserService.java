package com.example.demo.service.impl;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.User;
import com.example.demo.repository.UserRepository;
import com.example.demo.service.IUserService;



@Service
public class UserService implements IUserService{

	@Autowired
	private UserRepository repository;
	
	
	@Override
	public int addUser(User user) {
		
		return repository.save(user).getLeadId() ;
	}

	@Override
	public List<User> getAllUser() {
		
		return repository.findAll();
	}

	@Override
	public User getUserById(int leadId) {
		
		return repository.findById(leadId).get();
	}

	@Override
	public void deleteUser(int leadId) {
		
		repository.deleteById(leadId);
		
	}

	@Override
	public int updateUser(User user) {
		
		return repository.save(user).getLeadId();
	}

	@Override
	@Transactional 
	public int updateUserEmailById(String email, Integer leadId) {
		
		int id = repository.updateUserEmail(email, leadId);
		
		return id;
	}

}
