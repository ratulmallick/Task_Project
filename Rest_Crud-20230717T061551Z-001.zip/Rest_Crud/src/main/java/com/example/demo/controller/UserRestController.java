package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.User;
import com.example.demo.service.IUserService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("/rest/action")
@Api(value = "STUDENT", description = "USER OPERATION")
public class UserRestController {

	@Autowired
	private IUserService service;
	
	//Add User
	@PostMapping("/save")
	@ApiOperation(value = "ADD NEW USER")
	public ResponseEntity<String> addUserAction(@RequestBody User user)
	{
	ResponseEntity<String> entity = null;
	try
	{
	int id = service.addUser(user);
	entity =new ResponseEntity<String>("Status : Success " + id,HttpStatus.OK);
	}
	catch (Exception e)
	{
	e.printStackTrace();
	entity =new ResponseEntity<String>("Unable To Process Save User : ",HttpStatus.INTERNAL_SERVER_ERROR);
	}
	return entity;
	}
	
	
	//Get All
	@GetMapping("/all")
	@ApiOperation(value = "GET ALL USERS")
	public ResponseEntity<?> getAllUserAction()
	{
	ResponseEntity<?> entity = null;
	try
	{
	List<User> list = service.getAllUser();
	entity = new ResponseEntity<List<User>>(list,HttpStatus.OK);
	}
	catch (Exception e) {
	e.printStackTrace();
	entity = new ResponseEntity<String>("Unable to FetchUser's Records", HttpStatus.INTERNAL_SERVER_ERROR);
	}
	return entity;
	}
	
	//Find By Id
	@GetMapping("/find/{id}")
	@ApiOperation(value = "GET THE USER FROM ID")
	public ResponseEntity<?> getUserByIdAction(@PathVariable Integer id)
	{
	ResponseEntity<?> entity = null;
	try
	{
	User u = service.getUserById(id);
	entity = new ResponseEntity<User>(u, HttpStatus.OK);
	}
	catch (Exception e)
	{
	e.printStackTrace();
	entity = new ResponseEntity<String>("Record Not Found : "+id, HttpStatus.INTERNAL_SERVER_ERROR);
	}
	return entity;
	}
	
	//Delete By Id
	@DeleteMapping("/remove/{id}")
	@ApiOperation(value = "DELETE THE USER FROM ID")
	public ResponseEntity<String> deleteUserAction(@PathVariable Integer id)
	{
	ResponseEntity<String> entity = null;
	try
	{
	service.deleteUser(id);
	entity = new ResponseEntity<String>("Record Deleted Success: "+id, HttpStatus.OK);
	}
	catch (Exception e)
	{
	e.printStackTrace();
	entity = new ResponseEntity<String>("Unable to Delete Record: "+id,HttpStatus.INTERNAL_SERVER_ERROR);
	}
	return entity;
	}
	
	//Update
	@PutMapping("/update")
	@ApiOperation(value = "UPDATE THE USER FROM ID")
	public ResponseEntity<String> updateUserAction(@RequestBody User user)
	{
	ResponseEntity<String> entity = null;
	try
	{
	int id = service.updateUser(user);
	entity = new ResponseEntity<String>("User Updated Success.."+id,HttpStatus.OK);
	}
	catch (Exception e)
	{
	e.printStackTrace();
	entity = new ResponseEntity<String>("Unable to Update User Proccess : ", HttpStatus.INTERNAL_SERVER_ERROR);
	}
	return entity;
	}
	
	//Partial Modify
	@PatchMapping("/modify/{id}/{email}")
	@ApiOperation(value = "MODIFY THE EMAIL FROM ID")
	public ResponseEntity<String> updateUserEmail(@PathVariable Integer id, @PathVariable String email)
	{
	ResponseEntity<String> entity = null;
	try
	{
	int sid =service.updateUserEmailById(email, id);
	entity = new ResponseEntity<String>("User Email Updated Successfully : " + sid, HttpStatus.OK);
	}
	catch (Exception e)
	{
	e.printStackTrace();
	entity = new ResponseEntity<String>("Unable to Prccess Request : ",HttpStatus.INTERNAL_SERVER_ERROR);
	}
	return entity;
	}
}
