package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.User;

public interface IUserService {

	public int addUser(User user);
	public List<User> getAllUser();
	public User getUserById(int leadId);
	public void deleteUser(int leadId);
	public int updateUser(User user);
	public int updateUserEmailById(String email, Integer leadId);
}
